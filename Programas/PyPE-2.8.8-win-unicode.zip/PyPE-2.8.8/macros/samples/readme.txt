
Some of these macros contain possible failure conditions when running
macros.  Copy them into your macros folder to discover what they are and
what to avoid.

Other macros offer additional functionality that some users may find
useful generally, or as an example of what can be done.
