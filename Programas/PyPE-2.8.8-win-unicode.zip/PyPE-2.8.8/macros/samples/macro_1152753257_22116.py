

creation_date = 'Wed Jul 12 18:14:17 2006'
name = 'Timeout Non-Failure #2 in Python 2.3'

def macro(self):
    while 1:
        1
        2
