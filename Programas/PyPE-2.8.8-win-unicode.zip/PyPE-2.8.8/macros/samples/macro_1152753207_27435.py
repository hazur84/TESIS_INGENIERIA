

creation_date = 'Wed Jul 12 18:13:27 2006'
name = 'Timeout Non-Failure #3 in Python 2.3'

def macro(self):
    while 1:
        pass
