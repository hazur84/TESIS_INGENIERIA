
import time

creation_date = 'Wed Jul 12 18:08:30 2006'
name = 'Timeout Non-Failure #1 in Python 2.3'

def macro(self):
    time.sleep(1)
    time.sleep(1)
    time.sleep(1)
    time.sleep(1)
    time.sleep(1)
    time.sleep(1)
